# Supplementary Material S1: individual layout regions

Upload each `actor_01.pdf` through `actor_25.pdf` separately. Each is a one-page vector drawing; there is no combined supplement PDF. Matching SVG files are editable, zoomable vector masters. Captions and names are listed in `captions.txt`; region numbers match Figure 4 of the main article.

The original regional hierarchy and spatial cutoffs remain: internal geometry of collapsed cells is summarized, but thin routing above the extent cutoff is preserved. These views show the expanded research atlas, not compact die footprints. Source GDS, placement and simulations are unchanged. Provenance and exact cutoffs are in `manifest.json` and `vector_manifest.json`.

Elsevier recommends EPS or PDF for vector artwork. Use the PDFs for submission; SVGs preserve the source artwork. Guide: https://www.elsevier.com/en-gb/about/policies-and-standards/author/artwork-and-media-instructions/artwork-overview (checked 2026-10-19).
