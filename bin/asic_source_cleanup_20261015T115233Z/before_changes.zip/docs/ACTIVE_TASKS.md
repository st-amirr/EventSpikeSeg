## Wire-hidden device views and full model figures — 2026-10-15

The user requested regeneration with invisible wiring in PLIF/injector panels and visible wiring in the native 64-state bank. KLayout now hides metal1–5 and via1–4 for panels (a)/(c), with enlarged device windows; bank panel (b) is unchanged. Source GDS files are not modified. Renderer: scripts/render_article_gds_devices.py; source hashes, windows and hidden layer pairs: article/figures/gds_device_manifest.json. These are device-layer illustrations, not complete connectivity views. Full current 140k architecture is restored to the main model section (page 3) as an editable vector TikZ diagram. Original 140k_v4.png is preserved in the appendix (page 8), explicitly identified as the earlier detail32/selector96/spike-count topology. Current model detail8/fusion40-to-16/continuous16-to-6 remains authoritative. Both appear in Blocks_figures.tex. Article: 8 pages; reusable figures: 5 pages; compiled and visually reviewed. No circuit changes or new simulations.

## Model detail preservation and section figures — 2026-10-15

The user requested preservation of the actual 140k model detail. The article now restores the architecture-search history, residual-block diagram, chronological training/loss schedule, XL/digital background, and adds a source-checked per-stage inventory (25 actors, 30,976,000 membranes). ASIC implementation remains the main focus. Panels (a) and (c) show original-coordinate GDS device sections instead of full sparse parent wiring; full views remain available. Article and reusable figure PDFs compile to 7 and 3 pages and were visually inspected. No physical rerouting or circuit simulation was performed.

# Active tasks

Updated2026-10-14. Article layout, representative consumption and PNG/SVG views are delivered.

## Current deliverables

- Analog article package: `artifacts/analog_asic/index.html`.
- Final hierarchical GDS: `artifacts/analog_asic/layout/EventSpikeSeg140k_GF180_Analog.gds` (537,103,416bytes; SHA256fb28eeb6bbc8901ad8594dcd4b5cc14450b7cae438bd5f239096c587f96d1d92).
- Figures: `artifacts/analog_asic/images/`, including the three true-vectorSVGs and PNGs.
- Consumption: `artifacts/analog_asic/consumption/summary.json`,22 required families/74 rows. Per-instance transients, reused rail traces, RMS DC samples and digital-library estimates are explicitly distinguished.
- Digital140k andXL documentation: `artifacts/ASIC/final/index.html` and `artifacts/ASIC_XL/final/index.html`. No digital full-chip completion claimed.

## Scope and limitations

Original epoch58 full-float analog topology and54,630,400 state identities including30,976,000 membranes remain preserved. External analog/control interfaces are documented. The full1024-state page lacks complete connected power/transient evidence; partition and leaf consumption are supplied. No compact die, calibrated accuracy, full-chip power, globalRC/IR/EM, manufacture or full-population5ms acceptance is claimed. Further circuit optimization is optional.

## Cleanup completed; user bin review pending

Review bin: `bin/asic_cleanup_2026-10-14_20261014T145109Z/`. All64,814 original files accounted for; retained originals are SHA256-verified. No deletions performed. Original evidence bytes/hashes are preserved; `artifacts/asic_artifact_index.json` maps old paths to retained or binned files. restore_artifacts.ps1 and the move inventory are in the bin. Do not delete the bin without explicit user instruction. Archive the seven docs before future edits. No new simulations or Docker images were started during cleanup.

## Documentation and article consolidation — 2026-10-15

Main `docs/` is the only canonical documentation directory. The user moved the analog package directly to `artifacts/analog_asic/`; the nested `final/` path is retired. Identical packaged docs are preserved in `bin/article_reorganization_20261014T203110Z`. Script cleanup retained 201 scripts and archived 2,074 attempt/backup/cache files in `bin/scripts_cleanup_20261014T163508Z`; all original hashes verified. Article and GDS figures are updated and compiled. `article/article.pdf` is the ASIC-focused manuscript; `article/Blocks_figures.tex` and `article/figures/Blocks_figures.pdf` contain reusable physical-layout figures. KLayout produced native bank/injector GDS views and a PLIF cell directly from the delivered full GDS. No new circuit simulation was needed.
