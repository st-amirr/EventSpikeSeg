# Active tasks

Updated 2026-10-13. This page is the current operational scope. Earlier task requirements are archived.

## Active scope clarification — 2026-10-13

The user defines this deliverable as an article-suitable analog/mixed-signal implementation of the EventSpikeSeg140k architecture: full physical layout with membrane storage and event-to-membrane accumulation, followed by per-module simulations. The original epoch58 float model defines topology and state identities; QAT is unnecessary.

The 5 ms real-time requirement applies to delivery and accumulation of supplied input events onto their destination membranes. It does not require threshold/output generation, a full layer-to-layer inference pass, or final segmentation within 5 ms. For module timing, state exactly which input event workload and destinations were exercised; do not infer a full-model deadline pass from a small example. Later-layer workloads may be supplied externally for module characterization; this is not autonomous end-to-end inference.

Trained-weight loading, transfer, programming and exact checkpoint weight reproduction are outside the required completion gates. Retain the synaptic contribution/weight-control interfaces and existing physical synapse circuitry: an externally applied analog magnitude/sign is an explicit research interface, not a claim of loaded trained weights. Events must still have physical paths to selected membrane capacitors; removing weight transfer does not remove event fanout, charge injection or membrane access time.

A useful segmentation output, hardware mIoU, PyTorch-equivalent accuracy, calibration optimization and manufacture-ready signoff are not required. Preserve existing threshold/reset/adaptation/readout modules as architecture components and report their connectivity and simulation coverage, without requiring output completion for the accumulation deadline.

Completion requires a real hierarchical full-architecture GDS, inventory and connection/boundary manifest, and per-module simulation results including selected-event membrane accumulation/retention and measured timing. Explicit external interfaces are allowed. Opens/shorts in paths claimed connected remain vital defects. Never call an unconnected placement a functioning full ASIC or claim 5 ms compliance without corresponding evidence.

Next work: integrate the existing packet fabric and ingress/address macros with the membrane-access/injection architecture, expose analog contribution and phase controls, export the full architecture layout, then finish per-module simulations. Do not start trained-weight programming or output-accuracy campaigns. The old 68-decision-service lower bound is not an active completion gate. Existing packet/group lower bounds remain conditional on their supplied workload and assumed delivery architecture; they are not automatically waived or proven satisfied.

This scope supersedes conflicting older requirements below. Existing results and failures remain unchanged. No physical Docker jobs are live.

## Current physical stage

Latest connected full-population assembly remains V16: `artifacts/analog_asic/assembly/full25_spike_graph_v16/eventspikeseg140k_spike_graph_v16.gds` (351.68MB), with25 actual SPIKE outputs connected to the packet fabric. Full functional layout remains incomplete. Current jobs: decision-control V2 completed GDS/LEF/ODB/DEF/SPEF/netlist/Liberty, routedDRC0,21antenna nets/22pins,380slew violations. Its setup slack-28.6103ns at25ns/Fmax18.6531MHz fails40MHz. Decision-control V3 completed real physical views:40MHz setup+8.57772ns/hold+0.726315ns,nominal Fmax60.8929MHz,routedDRC0;981slew violations and23antenna nets/pins retained (`assembly/full25_decision_control_v3/physical_macro.json`); fixed-kernel25-actor ingress V2 has completed GDS/LEF/ODB/DEF/SPEF/netlist/Liberty in `assembly/full25_actor_ingress_v2/physical_macro.json`:1570.795um square (2.4674mm2),4804pins,nominal3.3V/25C setup+2.77583ns andhold+0.747967ns at40MHz, routedDRC0/antenna0.495slew violations retained; no whole-chip timing/signoff claim. Inspect each status.json and Docker identity before further action. Ingress V1 failed its4GB synthesis limit and is preserved; V2 passes ingress protocol and150000 categorical addressing comparisons across all25actual float configurations. Its143728 weight addresses cover PLIF actors;96head weights require separate readout service.

Current integration milestone: `artifacts/analog_asic/assembly/controlled_page_service_pair_v3/controlled_page_service_pair_v3.gds` (14.79MB) now connects two existing native1024page/compute/injector/writeback services to two independent physical access interlocks. Actual complete native+standardcell metal readback verifies84controller bindings,62legacy low ties/four high ties,shared supplies andphysical zero-state initialization reference; no new shorts/opens/unknown contacts/floating metal. Interlock V2 is427.995um square with40MHz setup+14.9232ns/hold+0.803807ns,DRC0/antenna0/slew0. The two native services retain192working/legacylocal slots each, which are not extra model identities. Source analog geometry remains unchanged. Current package: `assembly/controlled_page_service_pair_v3/delivery_stage_v1.json`.

Full architecture integration remains incomplete. Trained-weight programming and output-generation deadlines are now excluded by user direction; event-to-membrane paths and their timing remain required.

## Current evidence

- Full-population V16: `artifacts/analog_asic/assembly/full25_spike_graph_v16/physical_assembly.json`.
- Connected native page access/injector pair: `artifacts/analog_asic/assembly/controlled_page_service_pair_v3/independent_readback_v3.json`.
- Native independent page roots: `artifacts/analog_asic/assembly/parallel_storage_roots_v4/independent_readback_v1.json`.
- Existing module simulation coverage: `artifacts/analog_asic/assembly/full25_class_current_service_v13/module_simulation_coverage_v1.json`; coverage is historical evidence, not a new full-chip pass.
- Docker cleanup: `artifacts/analog_asic/operations/storage_cleanup_20261013/cleanup_summary.json`; terminal containers removed, canonical views retained. Use --rm for bounded simulations and archive/remove detached jobs on completion.

## Working rules

Layout first, then per-module simulation. Only vital connectivity/function changes. Use existing modules, existing Docker images and existing docs; no new Markdown files, no QAT/digital membrane fallback, no full-model SPICE, no subagents without authorization. Preserve unique artifacts and failed evidence. Archive the seven project docs before changing them.

Previous operational text: `docs/documentation_history/project_docs_before_accumulation_scope_20261013T143018Z.zip`.
