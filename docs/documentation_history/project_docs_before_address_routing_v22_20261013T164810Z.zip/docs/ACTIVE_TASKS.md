# Active tasks

Updated 2026-10-13. This page is the current operational scope. Earlier task requirements are archived.

## Active scope clarification — 2026-10-13

The user defines this deliverable as an article-suitable analog/mixed-signal implementation of the EventSpikeSeg140k architecture: full physical layout with membrane storage and event-to-membrane accumulation, followed by per-module simulations. The original epoch58 float model defines topology and state identities; QAT is unnecessary.

The 5 ms real-time requirement applies to delivery and accumulation of supplied input events onto their destination membranes. It does not require threshold/output generation, a full layer-to-layer inference pass, or final segmentation within 5 ms. For module timing, state exactly which input event workload and destinations were exercised; do not infer a full-model deadline pass from a small example. Later-layer workloads may be supplied externally for module characterization; this is not autonomous end-to-end inference.

Trained-weight loading, transfer, programming and exact checkpoint weight reproduction are outside the required completion gates. Retain the synaptic contribution/weight-control interfaces and existing physical synapse circuitry: an externally applied analog magnitude/sign is an explicit research interface, not a claim of loaded trained weights. Events must still have physical paths to selected membrane capacitors; removing weight transfer does not remove event fanout, charge injection or membrane access time.

A useful segmentation output, hardware mIoU, PyTorch-equivalent accuracy, calibration optimization and manufacture-ready signoff are not required. Preserve existing threshold/reset/adaptation/readout modules as architecture components and report their connectivity and simulation coverage, without requiring output completion for the accumulation deadline.

Completion requires a real hierarchical full-architecture GDS, inventory and connection/boundary manifest, and per-module simulation results including selected-event membrane accumulation/retention and measured timing. Explicit external interfaces are allowed. Opens/shorts in paths claimed connected remain vital defects. Never call an unconnected placement a functioning full ASIC or claim 5 ms compliance without corresponding evidence.

Next work: integrate the existing packet fabric and ingress/address macros with the membrane-access/injection architecture, expose analog contribution and phase controls, export the full architecture layout, then finish per-module simulations. Do not start trained-weight programming or output-accuracy campaigns. The old 68-decision-service lower bound is not an active completion gate. Existing packet/group lower bounds remain conditional on their supplied workload and assumed delivery architecture; they are not automatically waived or proven satisfied.

This scope supersedes conflicting older requirements below. Existing results and failures remain unchanged. See the current physical-stage record below.

## Current physical stage — destination-controller integration, 2026-10-13

Latest qualified full-population research GDS is V19: `artifacts/analog_asic/assembly/full25_accumulation_dispatch_v19/eventspikeseg140k_accumulation_dispatch_v19.gds` (532,403,802 bytes), top `ESS140K_ACCUMULATION_DISPATCH_V19`. Actual GDS integration readback passes: all source state geometry and top placements preserved, all 25 native spike-to-fabric connections retained, 1,475 fabric-to-ingress routes and 1,575 ingress-to-destination-controller routes present, and shared clock/reset connected across those three control macros. All 1,622 native membrane address/select escapes are preserved. These escapes are NOT yet wired to the controller's 947 grouped address-output nets. Full layout completion and 5 ms accumulation remain unproven.

Destination controller is now physically complete: 1,842.61 um square, 4,729 pins, nominal GF180 3.3 V/25 C at 40 MHz setup +9.27429 ns and hold +0.837844 ns, Fmax 63.5901 MHz, routed DRC0. Retain 8 antenna nets/pins and 501 slew violations. These are macro results, not whole-chip timing. All 25 actual actor configurations passed 1,425 categorical groups / 4,358 service requests / 125 invalid-input cases, including every local-bank exception, bank9 gap, edge coordinates, duplicate destinations, backpressure and fresh-done qualification. Analog completion in that test is a fixture; it is not charge/timing evidence.

Native access escapes V18: actual GDS readback verifies 1,622 M5 connections beyond the enclosing native wrappers, no opens or same-layer aliases, unchanged native source elements, and preserved earlier spike/event routes. Same-layer corridor screening includes the enclosing native hierarchy and a 460 nm guard. It is not full-style DRC or native RC/analog timing. Controller-to-ingress link V2 verifies all 3,050 inherited/new event routes plus shared clock/reset in the actual metal graph, with zero opens, aliases, floating metal/cuts, foreign or unknown contacts within the checked 2 um native macro perimeter bands, and no intrusion beyond those bands. Earlier V1 route plan is retained: its oversized .60 um pads triggered conservative clearance failures; V2 uses .46 um pads with .26 um cuts and .10 um enclosure, retaining the clearance check.

Next executable stage: route the 947 controller address-output nets to the 1,622 native local/forest membrane terminals, using the exact physical driver/sink coordinates and obstacle bounds in `artifacts/analog_asic/assembly/native_address_route_inputs_v1/routing_inputs.json`. Preserve the existing three-macro graph and 25 spike paths. Analog signed contribution and operation phases remain explicit external research interfaces under the user's scope; correct selected-service read/restore/inject/capture/commit and row preservation are required. Finish global supply/reference/clock/reset distribution, export the final architecture views/boundary manifest, then finish per-module connected accumulation/retention/timing simulations. Trained-weight transfer, useful segmentation output and hardware mIoU remain excluded gates.

All Docker jobs are terminal and collected. The destination-controller container was archived and removed automatically after final physical views/logs were saved; no new image was built. No host assembly/readback process remains live. Preserve the existing final views and failed attempts. The layout remains a spacious research atlas; no compact die area, loaded global-wire timing, autonomous inference or 5 ms throughput claim.

Evidence: `assembly/full25_accumulation_dispatch_v19/independent_readback_v1.json`, `assembly/accumulation_dispatch_link_v2/independent_readback_v1.json`, `assembly/full25_membrane_address_breakouts_v18/independent_readback_v1.json`, `assembly/full25_accumulation_dispatch_v1/physical_macro.json`, and `results/accumulation_dispatch_v1/simulation.json`, all under `artifacts/analog_asic/`.

## Current evidence

- Full-population V16: `artifacts/analog_asic/assembly/full25_spike_graph_v16/physical_assembly.json`.
- Connected native page access/injector pair: `artifacts/analog_asic/assembly/controlled_page_service_pair_v3/independent_readback_v3.json`.
- Native independent page roots: `artifacts/analog_asic/assembly/parallel_storage_roots_v4/independent_readback_v1.json`.
- Existing module simulation coverage: `artifacts/analog_asic/assembly/full25_class_current_service_v13/module_simulation_coverage_v1.json`; coverage is historical evidence, not a new full-chip pass.
- Docker cleanup: `artifacts/analog_asic/operations/storage_cleanup_20261013/cleanup_summary.json`; terminal containers removed, canonical views retained. Use --rm for bounded simulations and archive/remove detached jobs on completion.

## Working rules

Layout first, then per-module simulation. Only vital connectivity/function changes. Use existing modules, existing Docker images and existing docs; no new Markdown files, no QAT/digital membrane fallback, no full-model SPICE, no subagents without authorization. Preserve unique artifacts and failed evidence. Archive the seven project docs before changing them.

Previous operational text: `docs/documentation_history/project_docs_before_accumulation_scope_20261013T143018Z.zip`.
