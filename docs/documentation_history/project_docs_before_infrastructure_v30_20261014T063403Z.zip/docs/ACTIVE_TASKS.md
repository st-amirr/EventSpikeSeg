# Active tasks

Updated 2026-10-14. This is the authoritative operational scope; dated older requirements are historical.

## Goal and completion scope

Complete an article-suitable EventSpikeSeg140k original-float analog/mixed-signal full architecture layout, then per-module simulations. Preserve epoch58 topology, physical state identities and analog membrane storage; no QAT or digital numerical-state fallback.

The **5 ms deadline applies only to supplied input-event delivery and membrane accumulation**. Output generation, full layer-to-layer inference and segmentation need not complete in that time. Report the exact workload and destinations measured; a small module example does not prove full-population throughput. Later-layer module workloads may be externally supplied.

Trained-weight loading/transfer/programming, exact trained-weight reproduction, hardware mIoU, PyTorch-equivalent accuracy, calibration perfection and manufacture-ready signoff are excluded completion gates. Signed analog magnitude/sign and operation phases may be explicit external research interfaces. Keep existing output/threshold/reset/adaptation/readout circuitry as architecture components and report coverage. Do not start weight-programming or accuracy campaigns.

Completion still requires actual hierarchical full-architecture GDS, state inventory and connection/boundary manifest, plus per-module results including selected-event accumulation/retention and measured timing. Opens/shorts in claimed connections are vital defects. Do not call an unconnected placement a functioning ASIC or claim 5 ms without matching evidence.

## Current stage: supply/reference and external-control integration

Latest qualified full-population GDS is **V26**, `artifacts/analog_asic/assembly/full25_analog_references_v26/eventspikeseg140k_analog_references_v26.gds`. Cumulative evidence: `integration_readback_v1.json` in that folder.

Completed and preserved:

- All 54,630,400 analog state identities, including 30,976,000 membranes.
- 25 native spike-to-fabric routes, 1,475 fabric/ingress routes, 1,575 ingress/controller routes, and shared three-control-macro clock/reset.
- 947 destination-controller address nets reaching 1,622 native membrane address/select terminals: V23 actual parent graph/native edge readback passes.
- 1,750 supply/reference/phase/contribution terminals extended to native-wrapper boundaries: V24 actual geometry and corridor readback passes.
- Both analog supply networks reach 100 actor/forest terminals: V25 actual GDS graph passes.
- Storage/compute reference networks reach 100 actor/forest terminals: V26 actual GDS graph passes.

These are physical connection results. Thin research supply routes are not IR/EM qualified; global atlas wire RC, analog loading and 5 ms throughput remain unmeasured. The layout is a spacious research atlas, not a compact reticle-sized die.

## Next work

1. Finish the three categorical macro supply interfaces and class-current infrastructure; classify the other retained parameter/protocol module interfaces without launching a trained-weight campaign.
2. Finalize external contribution/phase boundary manifest and actual service-completion contract. Preserve unselected row columns during shared read/restore/inject/capture/commit; an address acceptance or timer fixture is not analog completion.
3. Export the complete layout/interface inventory, then finish connected per-module accumulation, retention and timing simulation coverage. Reuse existing module results and report measured errors; only vital changes.

Host native control-power inspection `scripts/prepare_gf180_control_power_v27c.py` is live (unified session 94628). V27 routing and V28 class-interface export/check scripts are prepared, not yet run. Two slower read-only inspections were deliberately stopped and preserved under `assembly/control_power_inputs_v27` and `v27b`; V27c uses upper-metal filtering and a byte-equivalent streaming GDS cell reader. No Docker jobs are live. V20/V21/V22 failed routing plans remain available. Do not repeat completed address, escape, supply or reference stages.

## Workflow

Use existing scripts/modules/images/docs. No new Markdown files, no full-model SPICE, no subagents/Astra. Archive the seven project docs before edits; preserve unique artifacts, source hashes and failed evidence. Foreground Docker simulations use --rm. Detached jobs must collect results, archive logs/inspect/exit and remove terminal containers; do not routinely delete images/volumes or live jobs. Latest storage cleanup evidence is `artifacts/analog_asic/operations/storage_cleanup_20261013/cleanup_summary.json`.

Historical module coverage: `artifacts/analog_asic/assembly/full25_class_current_service_v13/module_simulation_coverage_v1.json`. It records useful successes and limitations; it is not a new complete-chip pass.
