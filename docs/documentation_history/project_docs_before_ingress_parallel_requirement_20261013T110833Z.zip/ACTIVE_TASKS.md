# Active tasks





Updated2026-10-13. Read this page first, then only evidence needed for the next decision. Exact earlier index archived in documentation_history.





## Active task

**Complete the full EventSpikeSeg140k analog ASIC layout, then complete per-module simulations.** Use the original epoch58 float model and existing physical modules. Carry measured errors; make only fixes vital to connectivity or operation. Calibration and behavior optimization are deferred until the full layout is assembled.

Latest connected full-population assembly: `artifacts/analog_asic/assembly/full25_spike_graph_v16/eventspikeseg140k_spike_graph_v16.gds` (351.68MB). All25 actual analog SPIKE outputs connect to the routed25-adapter/event-graph packet fabric; independent GDS readback verifies25distinct paths, no new shorts/opens/floating metal and incremental inter-net spacing. All native analog child/state geometry retained. The packet fabric now has completed GDS/LEF/ODB/DEF/SPEF, both supplies physically connected and a completed nominal power report. Live controller physical job: `ess-gf180-full25-decision-control-v2`, provenance `artifacts/analog_asic/assembly/full25_decision_control_v2/status.json`. Its corrected categorical address/result protocol passes; full490240-bank mapping audit covers30976000validmembranes. Next: finish/bind address/sample control, trained-weight/input services and required parallel state access. One serial service peractor is now proven insufficient for5ms: even ideal three-cycle results at40MHz take0.33792s for the largestactor, requiring at least68parallelservices before analog timing/traffic. Keep5ms acceptance false; choose actual parallelism from loaded native service evidence. Full functional layout, loaded parentRC, original-float accuracy and5ms service remain incomplete. Delivery evidence: `artifacts/analog_asic/assembly/full25_spike_graph_v16/delivery_stage_v1.json`.

## Current stage





**Current stage: Full-chip research layout completion first, then per-module simulation, per explicit user direction2026-10-13. Carry current measured imperfections forward. Start from V13 full-population numeric-state access assembly and existing physical module library; physically implement and connect the25-actor event graph, actor/event boundaries, parameter delivery and phase/address controls. Fix only missing connections, shorts/opens, absent required functions or faults preventing operation. Defer calibration refinements, behavior optimization and repeated accuracy screens until the full layout is assembled. Analog state and original epoch58 float parameters remain the architecture. Full layout and population5ms/accuracy validation are incomplete; do not claim placement/capacity alone completes functional layout.**





Goal: article-suitable original-float EventSpikeSeg140k analog ASIC with full layout and per-module simulations. Preserve trained semantics and5ms updates. Manufacture-ready signoff is outside scope; record imperfections and refine connected modules.





| Position | Summary |


| --- | --- |


| Completed artifacts | 20 reusable module sets and89 characterization assemblies; catalog revision104 |


| Storage | Native3T/50fF under-MIM bank with shared column bias; core49.3% smaller,biased bank40.3% smaller;5ms/50ms child sequences complete |


| Shared access | Composed180us analog physical cycle completes159.67s:restore,beta,event,spike,reset,writeback. Native1832primitives/14365verifiedC;external categorical phases. Writeback error20.34mV retained;fullnativecontroller cycle remains partial. |


| Analog row writeback | Eight serial analog captures commit one full row; final error37.18mV;56other cells change0.300mV total/0.03385mV during commit |


| Voltage contract | Native state sampler/read/restore tests cover differential storage from-0.9V to+0.9V around1.65V, with maximum tested roundtrip error8.24mV. The float state is already defined as capacitor voltage: Vstored=1.65V+0.9*state/range for each guarded original-float 8x8 bank interval. A 490,240-entry scale table now spans the measured cell operating window. v5 81-point transient check: max relative scale-current error 0.1505%; v6 first-order residual correction and independent 81-point check reduce this to 0.00235%. The eight-record software replay still changes 28.96% of pixels under this injected residual, with mean IoU +0.0123; record0 remains similarly perturbed after scaling the residual another 1000x smaller. The actual routed3T/50fF cell now passes nominal write/5ms-hold/read screens at0.75/1.65/2.55V with VCM=1.65V: write error max6.14mV, held excursion max13.47mV, read-release disturbance max4.03mV. The storage span is physically plausible, but the buffered reader has uncalibrated0.797-1.213V offsets. The separate v8 pulse-injector/state cell passes DRC/LVS/GDS readback; at center, beta-before-event gives +13.15/-12.66mV matched steps and <=0.01mV displayed drift. At the full voltage endpoints, center-calibrated pulse bias gives apparent polarity reversal: low-state negative +44.65mV; high-state positive -54.18mV. Stronger biases restore sign but deliver -360mV/+41.76mV. A switched-cap packet prototype moves correctly at each endpoint, but the precharge/common-mode sample disturbs the membrane and uses an ideal common-mode fixture. The charge-delivery method and full-float recurrence remain open. This software sensitivity surrogate is too threshold-sensitive to predict full PLIF accuracy or acceptance. State conversion is explicit; update-current transfer, arithmetic, PVT/noise and complete recurrence remain unqualified. |


| Connected tile | Guarded579MOS8R172MIM tile: DRC0/exact759device wiring,5337nativeC. Completed260us measured resetrepair;reset-6.722mV,target-6.875mV;writeback-20.345mV. |


| Current accuracy gap | Beta residual-12.396mV and writeback20-28mV remain documented. Loaded resetduration derivedfromdonor,not independentprecisionpass. Wholemodelaccuracy unproven. |


| RMS/adaptation | Full64 nativeRC nominal complete. Full128 SUM/threshold nativeprimitive nominal now complete:sum10.46mV,threshold9.67mV;routeC excluded. Native128ROOT joins physically present in9actors,DRC0/exactcomposition;loaded nominal/producer bindings open. |


| Full model | V13all54630400analogstate identities havephysicalsharedaccess paths. Class-current parentproof/inventory pass;V12membrane/AGE/AMP geometry preserved. Categorical 25-actor graph interconnect now routes 53 packet edges with a bounded event-fanout/upsample smoke pass; analog actor compute bindings, continuous parameters, phase sequencing and physical parent routing remain. ParentRC/loadedupdates/accuracy/5ms unqualified. |


| Weight delivery | Continuous native-MIM voltage with nonlinear gate-current mapping. New actual-held-cell recalibration lands q1e-5 and q1e-4 at1.18x target charge in the same four-branch extracted setup (TT27,1us write ramp); full scale remains unity. The older 44x/6.3x report used transparent-writer gate points and is superseded for this held-cell operating point. Gate remains stable during READ; lowest-float range, repeatability/PVT/noise, addressed read, model accuracy and5ms service remain open. Keep all original floats. |





## Next work package

1. Complete the full research layout using the existing V13 state-access assembly and physically checked modules. Carry measured imperfections; no calibration gate before assembly.
2. Synthesize/place/route the existing full25 categorical event graph and integrate its real GDS/LEF into the physical top. This is spike/address control; numerical state and weights remain analog.
3. Bind every actor output/input packet boundary to actual spike serializers, weighted-event addressing and analog compute service. Connect the final analog class-current/readout edge.
4. Connect trained continuous parameter storage/distribution and required phase/address sequencing. Fix missing producers, shorts/opens and non-operating interfaces as vital issues.
5. Assemble/export the complete hierarchical GDS, physical connection inventory, views and module catalog. State unfinished connections explicitly; do not relabel an unconnected atlas as complete.
6. After the full layout, run required per-module/connected-module simulations using the actual assembled/extracted boundaries. Reuse existing evidence and report residual errors without unnecessary improvement campaigns.
7. Deliver the article layout and simulation package with area, timing, errors and coverage. Accuracy/5ms claims require matching evidence; manufacture-ready signoff is outside scope.

No critical user decision is pending. Continue autonomously; raise only a consequential unresolved architecture/scope tradeoff.





## Current evidence and boundaries





- Currentphysicalcandidate/simulationcoverage: `artifacts/analog_asic/assembly/full25_class_current_service_v13/article_report_v1.html`. Allnumericstateboundaryaccess built;globalfunctions incomplete.


- Full categorical graph interconnect: `asic/analog/gf180_analog_full25_event_graph_interconnect_v1.sv`; 25 actor packet interfaces and 53 of 54 graph edges are represented (the final class-current/readout edge remains an analog boundary). Verilator smoke passes ingress multicast and project3 nearest-neighbor expansion through decoder2 concat. Yosys hierarchy/check has zero undriven nets and SCC check finds zero combinational loops. Evidence/limitations: `artifacts/analog_asic/assembly/full25actor_event_graph_interconnect_v1.json`; simulator harness: `artifacts/analog_asic/benches/sim_gf180_full25_event_graph_v1.cpp`. Icarus 11.0 does not advance on this full-graph upsample event; retain that simulator-specific issue, use the passing Verilator run for this bounded smoke, and do not infer full graph acceptance.


- Original-float membrane ranges: `artifacts/analog_asic/results/gf180_float_state_tile_calibration_dc685af8e3_srcc47640d01bc7.json`; eight validation calibration records, all25 actors and30,976,000 states. 490,240 8x8 tile ranges use25% margin and at least4x per-channel threshold. Absolute range spans1.5719-19,100.21 model units (median102.33); this justifies local tile/channel float-to-voltage scaling. The calibration preserves baseline prediction hashes but does not implement or qualify per-tile analog gain/reference distribution, storage accuracy, unseen-scene headroom, noise, leakage or5ms service.


- Per-bank scale feasibility: `artifacts/analog_asic/results/gf180_membrane_scale_hardware_requirements_v1.json`. The v2 map spans12,151:1 across490,240 banks; existing pulse-duration command window is60:1. Measured8.238mV storage round-trip error maps to0.915% of each bank range. The extracted held 9-MIM cell plus routed PFET parent now passes DRC/LVS/GDS roundtrip; physical-parent transient with extracted capacitances reports minimum/median scale-current fractions0.00008132/0.014918 versus targets0.0000823/0.01536 after5ms (about-1.2%/-2.9%), with held-gate movement roughly 7-8mV. Evidence: `artifacts/analog_asic/layout/gf180_membrane_scale_current_cell_v6/qualification.json` and `artifacts/analog_asic/results/gf180_membrane_scale_mim_gate_reader_v4.json`. This is a nominal single-cell reader screen: scale writing map is not recalibrated; no multiplier, membrane recurrence, PVT/noise, model replay or full-population5ms service. Parent macro bbox is780.3x414.2um, so area scaling and shared-resource options are the immediate design gate. Prior 5us held-cell-only screen and divider estimate are superseded for this assembled operating point.


- Held membrane scale-current source: prior held-cell-only report `artifacts/analog_asic/results/gf180_membrane_scale_held_current_cell_v1_src6ca87d3a5103.json` remains historical. It is superseded for assembled-cell behavior by the routed parent and extracted 5ms reader result above. No multiplier, state-update, PVT/noise, inference or5ms population-service acceptance is established.


- Coarsened-scale original-float stress replay: `artifacts/analog_asic/results/gf180_membrane_scale_coarsening_replay_summary_v1.json`; all eight calibration-record baselines reproduce saved prediction hashes. Adding the measured8.238mV round-trip bound after every PLIF update and clipping to bank rails gives16x16 mean mIoU deltas-0.0206 (alternating signs),-0.0354 (positive),-0.0495 (negative); average pixel changes41.2-45.9%, clipping7.7-14.9%. At8x8 alternating signs delta is+0.0044, pixel changes31.9%, clipping2.51%, showing that this bound-injection surrogate is not a measured device-error distribution and not reliable acceptance evidence. Keep8x8 and prioritize tighter storage/update error. Individual reports `gf180_membrane_scale_coarsening_replay_record0_v2.json` through `...record7_v2.json`; source `scripts/replay_gf180_membrane_scale_coarsening_v2.py`.
- Bank-sharing range analysis: `artifacts/analog_asic/results/gf180_membrane_scale_bank_coarsening_v2.json`. Grouping adjacent 8x8 ranges to 16x16 reduces scales 490,240 to 126,400; the nominal 8.238mV storage bound maps to median 0.969%, p95 1.803%, p99 8.823% of each source 8x8 range, with 1.466% of membrane identities over 5% and 0.946% over 10% (maximum 714%). At 32x32, 33,920 scales remain but 3.264%/1.794% of states exceed 5%/10%, maximum 4,262%. This is range arithmetic only, not analog recurrence or accuracy replay; retain 8x8 for now. Source: `scripts/analyze_gf180_membrane_scale_bank_coarsening_v2.py`.

- Membrane bank scale map: `artifacts/analog_asic/assembly/membrane_voltage_scale_manifest_v2.json`; exact range-to-selector mapping for all30,976,000 membrane identities and490,240 scales, one shared scale per 8x8 spatial/channel bank (maximum64 state cells each). It maps each guarded float range ontoÂ±0.9V around1.65V using the native storage/read/restore range test (0.75-2.55V; maximum sampled roundtrip error8.24mV). This is nominal sampled module evidence only; physical scale storage/application, mismatch/noise/PVT and all recurrence terms remain unqualified. Existing calibrated16x local pulse-gain injection is not yet connected to this bank map.


- Categorical graph fanout: `event_fork2` simulation, routed GDS, flattened full-style DRC and LEF/Liberty import pass; evidence: `artifacts/analog_asic/results/gf180_analog_event_fork2_v1.json`. This does not complete graph binding.


- Categorical 2x event fanout: `event_upsample2x` simulation, routed GDS, flattened full-style DRC and LEF/Liberty import pass; evidence: `artifacts/analog_asic/results/gf180_analog_event_upsample2x_v1.json`.


- Categorical event joins: `event_join2` simulation, routed GDS, flat full-style DRC and LEF/Liberty import pass; mismatch fails closed and matching-bin completion rendezvous verified. Evidence: `artifacts/analog_asic/results/gf180_analog_event_join2_v1.json`.


- Residual OR and actor event order: four 32-lane serializers plus the sorted merge tree pass a 128-neuron page simulation, including a partial tail and completion rendezvous. The flattened parent has routed GDS/SPEF/LEF/Liberty; detailed-route violations are 0 and Magic full-style flat DRC is 0. ORFS final timing reports 120 max-slew violations despite 0 setup/hold violations; carry this as an unresolved physical-quality issue. Analog comparator-to-bank binding and full actor-graph integration remain open. Evidence: `artifacts/analog_asic/results/gf180_analog_spike_event_page128_v1.json` and `artifacts/analog_asic/benches/gf180_analog_spike_event_page128_v1_tb.sv`.


- Analog comparator output handoff: measured near/high/low `SPIKE` voltages from the routed five-module neuron parent were classified at 0.7 VDD and passed through the routed page RTL; only the high arm emitted address 4001 with its completion tag. This verifies the voltage-to-bit interface in bounded co-simulation, not extracted physical wiring or a 128-channel analog bank. Evidence: `artifacts/analog_asic/results/gf180_neuron_spike_to_page128_v1.json`.


- Physical analog-to-digital parent: `artifacts/analog_asic/assembly/gf180_neuron_page_scatter_link_v1/qualification.json`; neuron SPIKE to routed page lane0, via3/via4 M3/M4/M5 route, flattened full-style DRC0, hierarchical extracted net verified. End-to-end measured waveform to pointwise weight selector simulation: `artifacts/analog_asic/results/gf180_neuron_page_scatter_cosim_v1.json`. Digital page/decoder/scatter ORFS view: `artifacts/analog_asic/orfs/results/gf180/gf180_analog_channel_pixel_page_to_pw128_scatter_v1/channel_pixel_v1/`.


- Signed analog weight delivery screen: `artifacts/analog_asic/results/gf180_weight_delivery_float_mapping_v1.json`; extracted GF180 sequencer/injector, 1.0V quiet zero,1.1V quarter-scale proxy, Â±1.4V full-scale events,0.15% charge mismatch. This is not loaded parameter-read, short-pulse, full-float accuracy or5ms service acceptance.


- Low-end weight transfer: `artifacts/analog_asic/results/gf180_weight_low_end_characterization_v1.json`; extracted nominal TT27 sequencer/injector reports no event at5% and10%, a10.35% full-scale charge at15%, and17.42% at20%. The1% simulation hit its300s bound without a waveform. Linear1.0â€“1.4V weight mapping is rejected pending circuit correction; this is not an accuracy or5ms service result.


- Fixed-duration analog amplitude transfer: `artifacts/analog_asic/results/gf180_physical_weight_amplitude_transfer_v5_src11e5a5445dc3.json`; extracted physical sampled-weight/current cell, native 9-MIM weight bank, extracted read switch and charge reader. At TT27, q0.1/q1/q5/q10/full charge ratios are0.0835%/0.9784%/4.9994%/9.8616%/100% of full-scale. The writer is transparent during this calibration run. Prior v1/v2 runs verify near-unity gate retention for their settings, not the final map. Charge differences are near aC; no noise/mismatch/PVT floor, addressed model replay or5ms service is proved. Failed v3 experiments are retained with solver-timestep diagnostics.


- Final-map sample/hold: `artifacts/analog_asic/results/gf180_physical_weight_amplitude_transfer_v6_hold_srcbfe471246216.json`; extracted native writer released before event, measured held gate voltage and charge for q0.1/q1/q5/q10/full. Final-map errors are +29.1%,+3.29%,+1.41%,-0.59%,0% relative to target; nominal only.


- Original-float weight range: the epoch58 full-float checkpoint SHA is verified and its historical/fresh exports are array-identical. The143824 weights across26 tensors have no exact zeros; minimum per-tensor-normalized magnitude1.67785047e-7, median5.6864%,2.002% are below0.1%, and0.387% below0.01%. `artifacts/analog_asic/results/gf180_physical_weight_amplitude_lowtail_v1_defaulttol_src560b1cb1ed2f.json` measures q1e-4 at0.0119% of full-scale charge; q1e-5, q1e-6 and the actual minimum are not distinguishable from zero at the simulator's reported precision. This is not proof of a physical noise floor or a reason to discard those values.


- Low-tail inference sensitivity: `artifacts/analog_asic/results/gf180_float_weight_lowtail_sensitivity_4record_summary_v1.json`; four full-frame epoch58 float records,10 updates, all25 actors. The continuous+29.1% gain applied to2,878 post-affine weights below0.1% changed9.59% of pixels on average; mean-IoU deltas averaged-0.000261 (range-0.000958 to+0.000607). This extrapolates the q0.1 measured gain to all smaller values and is one-record-per-scene-subset sensitivity, not full validation accuracy. The v1 sensitivity report uses pre-affine normalization and is superseded by v2.


- Settled low-current screen: `artifacts/analog_asic/results/gf180_physical_weight_amplitude_lowtail_v3_src2348b45e6cda.json`; averages source current only across the stable center of the1us event, then subtracts the zero branch before printing. Normalized q1e-4 yields0.01094% of full current against a0.01% target. q1e-5, q1e-6 and qmin yield negative or zero differences around1e-17A, so the current extraction/simulator composition does not resolve them. This is deterministic nominal residual, not a measured thermal/device noise floor and not proof of zero physical response.


- Refined low-tail inverse map: `artifacts/analog_asic/results/gf180_physical_weight_amplitude_lowtail_v9_calibrated_points_src276277417115.json` and `...lowtail_v10_calibrated_tightertol_src18ee534138df.json`. With1e-19A solver abstol, q1e-5 at3.1194V is9.96e-6/1.098e-5 full scale and q1e-4 at3.079V is1.081e-4/1.094e-4 across the two bench compositions. q1e-6/qmin differ materially; do not claim reliable transfer. Full low-tail sample/hold attempts fail at writer transition; existing q0.1-to-full hold is the only accepted held-map evidence.


- Physical held low-tail read: `artifacts/analog_asic/results/gf180_physical_weight_amplitude_transfer_v14_lowtail_hold_current_src9ace85408ed3.json`; with a1us physical write ramp, source/MIM/read simulation completes. At9us held gates are3.11859V and3.07821V against commands3.1194V/3.079V. Settled q1e-5/q1e-4 current fractions are4.386e-4/6.331e-4 of full scale; zero-subtracted integrated charges are4.471e-4/6.472e-4. Full-scale is unity. This held path is inaccurate at the low tail despite source-only inverse calibration.


- Held-gate diagnosis and recalibration: v17 confirms the stored gate changes only about0.01-0.02mV across READ, so read-edge gate disturbance is not the cause. The v19 multibranch sweep is a coarse map only. Four-case extracted recalibration v23 uses command gates3.294V/3.243V for q1e-5/q1e-4; measured held gates are3.29304V/3.24209V and zero-subtracted charge fractions are1.1767e-5/1.1767e-4 (about17.7% high), with full-scale unity. v22 coarse points were 2.28x/1.35x and motivated the v23 correction. Treat v23 as one nominal calibration point, not acceptance: minimum-weight transfer, composition variation, PVT/mismatch/noise, inference and5ms remain open. v21 tighter solver tolerance failed at the writer transition and is not evidence. Reports: `artifacts/analog_asic/results/gf180_physical_weight_amplitude_transfer_v17_hold_gate_during_read_src43c823780518.json`, `...v19_held_gate_map_sweep_srce8e9bce1faa4.json`, `...v22_held_gate_transfer_recalibration_srcaf2501b358a7.json`, `...v23_held_gate_transfer_recalibration_srca9018ecd8428.json`. Independent three-case composition checks in v24 reproduce q1e-5 at1.1789e-5 charge fraction and q1e-4 at1.2378e-4, each against 1e-5/1e-4 targets; full scale is unity. Settled-current fractions are1.2320e-5/1.1901e-4. Reports: `artifacts/analog_asic/results/gf180_physical_weight_amplitude_transfer_v24_independent_q1e5_src073f25f38f06.json` and `...v24_independent_q1e4_src75d4978d85ed.json`.


- Signed offset model sensitivity: `artifacts/analog_asic/results/gf180_float_weight_lowtail_offset_sensitivity_4record_summary_v1.json`; four validation-listed full frames, symmetric +/-1.5e-5 per-tensor full-scale offset applied continuously to the557 effective weights below1e-4. Mean-IoU shifts average+0.001078 toward zero and-0.000867 away; pixel changes average0.763% and0.713%. This is a sensitivity bound to deterministic nominal residual, not a physical noise/offset distribution or acceptance result.


- Channel concat remap: registered offset-64 macro passes simulation, routed GDS, full-style flat DRC and LEF/Liberty import; evidence: `artifacts/analog_asic/results/gf180_analog_event_channel_offset64_v1.json`.





- Catalog: `artifacts/analog_asic/assembly/article_module_catalog_v104.json`.


- Joined tile: `artifacts/analog_asic/results/gf180_shared_analog_compute_tile_v3_article_boundary.json`.


- Native sum/threshold: `artifacts/analog_asic/results/gf180_adaptation_sum8_threshold_v1_article_boundary.json` (8inputs only; full64/128groups remain).


- Shared threshold: `artifacts/analog_asic/results/gf180_shared_adaptive_threshold_v1_article_boundary.json`.


- Three-state native beta summary: `artifacts/analog_asic/results/gf180_tile_v3_fullcap_three_state_beta_summary_v1.json`.


- Export/phase review: `artifacts/analog_asic/results/gf180_shared_tile_v3_export_and_phase_review_v1.json`. Use `export_gf180_complete_flat_cap_v1.py` for future flat-C exports; check every native substrate node, not only nonnegative coupling branches.


- Beta phase diagnosis: `artifacts/analog_asic/results/gf180_joined_tile_beta_phase_partition_v1.json` (existing trace only).


- Row writeback: `artifacts/analog_asic/results/gf180_row_staged_writeback_v1_article_boundary.json`.


- Voltage bridge: `artifacts/analog_asic/results/gf180_storage_compute_level_bridge_v1_article_boundary.json`.


- Source/flat/GDS fullDRC0 and exact primitive graph bijections qualify joined connectivity. Native Netgen failures remain recorded; do not report them passing. One intentional tied-D/S dummy terminal warning and actual diffusion areas retained; junction-area precision unaccepted.


- New row_staged_writeback_v2 splits BUFFERED/COMMIT_DATA for down-shifter; its connection is exercised inside joined tile_v2. No direct unity-domain assumption.


- Storage capacity: `artifacts/analog_asic/assembly/full_capacity_storage_gds_v2/capacity_assembly.json`;54,630,400 active identities,866,080 actual8x8 banks,8,676.37mm2 storage/native bias only. Compute,decoders,global routes absent; whole-atlas native DRC/LVS incomplete.


- Parameters: `artifacts/analog_asic/assembly/float_parameter_capacity_v1/parameter_capacity_assembly.json`;143,824weights,1,856beta channels among147,567continuous float requests.39.43mm2 old bank geometry; actual programming/retention/calibration remain incomplete.


- User accepted1,215mm2 conditional bare-plate estimate; it excludes switches/periphery/routes and is not the physical bank/full-chip area.


- Longest same-bin dependency23PLIF stages;217.39us uniform-stage split is a planning reference. Cold/warm reader timing differs; `gf180_shared_reader_serial_budget_v2.json` contains conditional scenarios,not proof of5ms success/failure.


- Joined18.63mm-wide characterization fixture is deliberately spaced. Do not multiply this fixture footprint into a dense full-chip estimate. Full dense layout remains to build.





## Lightweight workflow





- One question,matching baseline,one changed mechanism,named metric,next action. Reuse existing traces and qualified modules.


- Initially at most3cases,120s,2CPU/2GB and one simulator;maximum2independent jobs. Measured runtime extensions need explicit basis.


- Two similar failures require diagnosis;one unsuccessful focused repair requires method review. No blind parameter/tolerance/runtime sweep.


- Freeze calibration before independent comparisons. Qualified children do not qualify a new parent. Record completed runs even when precision gates fail.


- Raw detail belongs in JSON/logs/source snapshots. ACTIVE_TASKS owns stage/jobs; RESULTS findings; DECISIONS choices; ARCHITECTURE semantics; PROGRESS milestones. YAML mirrors operational state.


- Archive exact existing seven docs before meaningful edits. Preserve consumed scripts/reports;version changes. No new Markdown,subagents,commits/remotes,deletes or full-model SPICE.





## Fixed scope and navigation





GF180 prototype,original epoch58 float checkpoint,analog numerical state. Categorical control/address/spike bits allowed. QAT/digital membrane fallback and XL/digital campaigns stay paused. Full objective active and incomplete.





[ARCHITECTURE](ARCHITECTURE.md) / [RESULTS](RESULTS.md) / [DECISIONS](DECISIONS.md) / [PROGRESS](PROGRESS.md) / [project_spec.yaml](project_spec.yaml).








## Connected1024-state page - 2026-10-11





Higher166MOS eight-way selector source/GDS fullDRC0 and independent native LVS unique; three-address READ/WRITE simulation with100fF fixture loads passes. Connected1024-state page:6326MOS1024MIM,source/GDS fullDRC0 and native LVS unique,real517.70x1667.12um GDS/LEF,60175verified flat native capacitance branches. Seven categorical row-address bits select one8-state row;8analog DATA trunks shared across eight128-state pairs. Readout/bias remain independently exposed. One120s bounded2us connected write sequence timed_out_or_incomplete; report `artifacts/analog_asic/results/gf180_selected_page1024_v1_native_two_page_write_v1.json`. Native initialization,shared reader/compute,5ms service and full ASIC remain incomplete. Catalog98:20module sets/78characterization assemblies. Evidence report:artifacts/analog_asic/assembly/selected_page1024_delivery_v1/report.html.





Connected-page runtime diagnosis:120s reached0.197193us of2us (9.86%);linear runtime projection about1217s is not a retry authorization. Keep failure,avoid full-page native transient campaign;next integration uses existing qualified128-state bank/selector evidence and bounded interface loading while binding shared reader/compute. Exact timestep bottleneck remains undiagnosed.








## Decoded shared read/write/compute integration - 2026-10-11





Catalog99:20module sets/81characterization assemblies. Decoded64-state reader100us native sequence complete;recovery21.43uVagainstactualstoredstate,writeerror21.58mV,read-phasepeakstatechange11.33mV/final.822mV;noUICseed. Source/GDS fullDRC0 and independent exact480primitive connectivity/dimensions;nativeNetgen propertywarnings retained,not cleanLVS. Sharedread/write service499MOS113MIM and compute tile579MOS8R172MIM now physicallyconnected;source/flat/GDS DRC0/exact612and759primitive proofs. FullC4416and5337branches. New tile230us cycleaborted25usonautozero release;notnominalpass. All25actorclusters now use decodedtile;full25_locally_decoded_storage_v2 preservesall54,630,400states. Globalbankservice/graph/operatorbinding and fullASIC remainincomplete. Report:artifacts/analog_asic/assembly/full25_locally_decoded_storage_v2/delivery_report_v3.html.








## Guarded connected update - 2026-10-11





Guarded tile579MOS8R172MIM: source/flat/GDS DRC0, exact759primitive connectivity,5337native capacitance branches. Fullcapacity guarded25actor GDS19.65MB preserves54,630,400active identities; firstactor native DRC0/exact1357primitive proof. Selected-row230us native cycle completes but fails subtractive reset (+0.234mV with spikehigh); positiveevent89.143mV,beta residual-12.396mV,writebackdifference-20.340mV. Native internalreset diagnostic running; no circuit/calibration fitting. Globalbankservice,graphoperators,remainingmodule simulations and fullfunctionalASIC incomplete. Current report:artifacts/analog_asic/assembly/full25_locally_decoded_storage_v3/delivery_report_v1.html. Historical reports remain scoped to their revisions.








## Measured loaded reset repair - 2026-10-11





Observed in the measured repair case. The adjusted reset pulse lasts 23.614 microseconds. Measured reset: -6.722 mV; requested: -6.875 mV. Writeback error: -20.345 mV. This is one donor-derived pulse-duration repair, not independent reset precision acceptance. The complete native reset path turns on correctly; prior pulse was too short under actual loading. No geometry/bias or beta-reference change; post-reset capture/commit delayed30us. Full functional assembly, global bank service, graph/operator binding and missing module simulations remain unfinished. Updated delivery report: artifacts/analog_asic/assembly/full25_locally_decoded_storage_v3/delivery_report_v2.html.








## Shared external resident-bank service - 2026-10-12





Shared128state reader:852MOS133MIM,source/flat/GDS DRC0/nativeLVSunique,8213verifiedfullC;70us native sequence completes,recovery21.37uV againstactualstoredstate,writeerror28.10mV,statechange1.667mV. Full25external-bank-servicev2 GDS23.94MB movesoneexisting128statepairperactor into sharedreader/upshift/startup-restore selector;8analogwritecolumns connectexistingcompute. Independentplane/binaryactorrootaudit preservesall54,630,400activeidentities,866005plane+75actorbanks. First192membranesperactor physicallybound;remainingbanks/globalgraph/operators stillunbound. DRC0 on corrected assembly; complete connectivity proof remains open. Fullparasiticactor120s extractionstimeout retained;freshconnectivity-only extraction disablesparasiticC,notnativeMOS/MIM/R. Catalog100:20module sets/84characterizationassemblies. Currentreport:artifacts/analog_asic/assembly/full25_external_bank_service_v2/delivery_report_v1.html. No wholemodelaccuracy/5ms/fullASICacceptance.








## Connected external-storage service completes - 2026-10-12





Actual firstactor2362nativeprimitives and17392complete verified routingC completes120us physical storage/read/upshift/compute-restore/capture/writeback,202.58s wall with KLU. Native categorical drivers retained;noideal DATA/state source,noIC/UIC. Reader64.57uV,compute restore4.93uV,writeback-20.27mV,totalroundtripchange-34.63mV,oppositebankchange-33.81uV. These imperfect results are retained andprecisionrefinement deferred while completing layoutconnections/missingfunctions. Nativecommit/event controllers remainreset inthiscase;fullneuronupdate andfullASIC remainincomplete. SPARSE-to-KLU stableepochanalogcomparison maximum3.56pV at5/20/24/28us,nottransition/accuracybound. Currentreport:artifacts/analog_asic/assembly/full25_external_bank_service_v4/delivery_report_v2.html.








## Article delivery priority and current revision - 2026-10-12





User accepts imperfect results: finish connected layout and per-module simulations first; retain measured errors and defer precision optimization. V5 service escapes moved to a clear left gutter after V4 larger-actor supply/signal shorts were found. All54,630,400 state identities preserved. Four recursively audited geometry groups cover25actors;24 actor geometries inherit representative DRC0,stem retains oneM5 spacing violation. Firstactor exact2362 primitive graph and fresh17268 routingC pass; larger-parent exact extraction incomplete and partialEXT rejected. Latest180us native neuron case: Incomplete: reached 105.209us of180us; retained as partial evidence. Full global bank service,graph/operator/parameter bindings and remaining module functions are still missing. Current delivery report: artifacts/analog_asic/assembly/full25_external_bank_service_v5/delivery_report_v1.html.








## Completed analog cycle and128-channel integration - 2026-10-12





180us analog physical partition completes159.67s wall:1832native primitives,14365complete verified routingC,DRC0/exact independentgraph. Only two categorical controllers removed from this characterization;fullASIC V6 retains them. Restore8.38uV,beta step-26.900mV,positiveevent+143.160mV,spike3.294V,reset-6.467mV,writeback error-20.341mV. Programmed pulse-width termination andprecision remain unaccepted; no ideal DATA/state orUIC/IC. Full128 SUM/threshold nativeprimitive40us threecase nominal completes:sum10.464mV,threshold9.671mV errors,localsettling7.503us. Source/GDS exact3099MOS512R1536MIM;routeC excluded andcompleteRC remains open. One240s extension justified by measured120s reaching22.1866us/40us,216.35s projection;no circuit/tolerance tuning. V6 actual9actor ROOT joins reuse existing two64halves;exact896primitive sharedROOT composition equals native128 reducer andnewrepresentativeDRC0. All54,630,400active identities preserved;globalbankservice/graph/parameter/producerbindings,loadedRMS128 andfullASIC remain incomplete. Report:artifacts/analog_asic/assembly/full25_shared_ROOT128_v6/delivery_report_v1.html.








## Shared1024state page and completed reader partition - 2026-10-12





Actual1024state page6818MOS1029MIM:sourceGDS DRC0,exact7847primitive graph,71802complete verifiedroutingC. Onefeedbackreader serves8bankpairs. Whole34us transient timedout120.59s at3.996us nearfirstaddressedge; retained,not a pass. New physical frontend partition354MOS5MIM preservesparentroutes/decoder/readTG/mux/reader:DRC0,exact359graph,9498verifiedC.40us A-B-A sequence completes36.41s;sampled recoveryerror22.03uVmax,Areturnchange2.514nV. Frozenmeasured nativebankRAW100ohmfixtures;notwholepage sourceimpedance/startup/retention/serviceproof. Continuefullphysicalbindings,retainimperfectresults,avoidprecision/runtimecampaigns. FullV6assembly unchanged;allmodelglobalservice stillincomplete. Catalog101:20modules86characterizationassemblies. Report:artifacts/analog_asic/assembly/shared_reader_page1024_v1/article_report_v1.html.








## Full25actor shared1024page physical integration - 2026-10-12





V8actualGDS moves200existingresidentpairs into25shared1024pages. NativepageDATA0..7 connectexistingcompute writecolumns;nativelevelshift/gatedrestore joins existingcompute numericalinput. Original64+128state service retained:1216routedsites/actor,30400total. Independentbinaryreadback provesall54630400activeidentities/866080banks withoutduplication;865605plane banks remainglobalserviceunbound. Fourexactrootgeometrygroups cover25actors;representativeDRC:15 actors with0 recorded DRC errors, 1 actors with1 recorded DRC errors, 9 actors withDRC incomplete. V7restoreTG shared-x M4escape short diagnosed;V8separateM3escapes implemented. V7flat/V8hierarchical120sextractions bothincomplete;no newparentexactwiring pass. Methodreviewrequires actualinterconnectpartition/qualifiedchildcomposition insteadofblindlargeretry. Completedimperfectmodule results retained;accuracy/5ms unproven. Report:artifacts/analog_asic/assembly/full25_shared_page1024_v8/delivery_report_v1.html.








## All25actor sharedpage boundary composition verified - 2026-10-12





Independent exactmetal/MIMcontact graph checksalloriginal/newmoduleterminal anchors. Fourexactgeometry+TEXT+sourcebinding groups cover25actors;every qualifiednativechildGDS cell byteverified afternamespace mapping. No shorts,opens,floatingadditions,unknownchildcontacts orrootporterrors. KnownbadV7control correctlydetects sixshortednets. GF180VIA4 withinCAPM contactsMIMtop75,notM4;earliernaive verifierinvalidated/retained. Streaminghierarchy avoids2GB exit137 fromexpandedcache;largestcase2724428rectangles/2364anchors completes31.41s. All25actor circuitboundary composition nowqualified,includingnineRMS128ROOTjoins. ThisisnotcompletedflatnativeLVS/RC/loadednominal. DRC15actorszero,stemoneerror,nineRMS128DRCincomplete remain. Nextglobalbankservice/graph/parameterbinding andmissingloadedmodulecoverage. Report:artifacts/analog_asic/assembly/full25_shared_page1024_v8/delivery_report_v2.html.








## Globalpage selection and fullpopulation address mapping - 2026-10-12





Native8way higherselector230MOS source/GDS DRC0/nativeLVSunique,2332complete verifiedroutingC.40us0-7-0 command/readout sequence completes12.06s;allWRITE/READ/ENABLE onehotchecks correct. Static100ohm childRECOVfixtures frozenfromnativefrontend,100fFloading provisional;notfulltree service/precision. V1export lacked.subckt;V2explicitrootwrapper fixesexport withoutcircuitredesign. Canonicalrank/inverse/base8 mapping exhaustivelychecks865605remainingbanks andall54630400activestates incl30400routed:54105leaf1024pages,7837higherselectors,75extra inactivebanks. Historicalfoundation status:physicalglobaltree subsequentlybuilt inV9. Nextactualrecursivehierarchy with8DATAperchild TG isolation,uniformaddressdepth/no tailaliases,originalidentitypreservation;thenmembrane/AGE/AMP/classcompute interfaces. Catalog102:20modules87characterizationassemblies. Report:artifacts/analog_asic/assembly/full_population_page_access_v1/foundation_report_v1.html.








## Full-population shared-access assembly V9 - 2026-10-12





ActualGDS replaces56rawplane rootinstances with54105native1024pages and7837higherselectors;25existingcomputeclusters/parametercapacity/protocolgeometry retained.54600000foreststates+30400actorstates=54630400active analogidentities. Binaryhierarchy verifies501568DATA-TG and62696inverters;15leafhierarchycells byteidentical. All33template exactparent/interface metalgraphs pass:0shorts/opens/unknowncontacts/floatingadditions/porterrors;parentroutes avoid opaquechildregions andnativeleafchildbounds independentlychecked. Staticbounding-volume indexing avoidslong-wire gridexplosion;55.16s complete. V1checker anchorquery included unconnectednewpaint beforeaddition;V2limitsbaselineanchors correctly,retainedV1 ischeckerfailure,notcircuitfailure. Newtop oldrawplanes absent fromreachablehierarchy. No newtransient run. Spaciousatlas only;fullnewtop identitybinding,forestcompute/adaptation/class/operator/parameter links,loading/DRC/RC,accuracy/5ms remainopen. Userprioritizes completionwithimperfectresults,precisioncampaigns deferred. Report:artifacts/analog_asic/assembly/full25_page_forest_v9/article_report_v1.html.








## Full membrane compute access V10 - 2026-10-12





Actual25wrapperGDS bindsall30976000membranes:forestRECOV throughnative16MOSupshift/2MOSgatedrestore toexistingactorEXTERNAL_COMPUTE_DATA,8sharedanalogwritecolumns returntoforest. All25boundarymetal/contactproofs pass withactualactorrootpaint andallnativechildsubtrees intersectingnewwire bounds;disjointsubtrees safelyexcluded,forestopaquearea guarded. Allinheritedchildcells byteidenticaltoV9. V2proof fixesindex0truthiness omissionandchecksaddedvia metalcontacts;retainedV1 notauthoritative. Independentbinarytopcensus proves56forestrootoccurrences/25actors/54130native1024pagesincl25localpages;actualallgeometry/TEXT/arraybounds fitdisjointplacement. Active54630400identitycontract inheritedunchanged. One374MOSselector+64DATA-TG+8inverter40us0-7-0nativechildcapboundarycase completes32.812s;allcommandsonehot,unselectedDATAchange11.702uVmax,selectederror2.075nV withstiff100ohm/100fFfixtures,notfulltreeprecision. ParentatlaswireRC excluded. No activeprocess. NextAGE/AMP/classplanevoltage/restore/writeback interfaces,then graph/parameter/sequencer/missingfunctions. FullfunctionalASIC,accuracy/5ms incomplete. Report:artifacts/analog_asic/assembly/full25_membrane_service_v10/article_report_v1.html.








## Adaptation shared access and release-coupling review - 2026-10-12





New172MOS84MIM IO:2restoreTG,oneAGEbuffer,16analoghold/outputbuffers. Source/GDSDRC0 andexact256primitive/pin/net/edge/dimensionproofs pass V1/V2/V4;nativeNetgen mismatchesretained. CompleteC2296/2296/2196branches. Three110us nativeIO+resident(131MOS48R34MIM)A-B-Acases complete27.84/25.38/23.27s withoutIC/UIC;frozen100ohmRECOVboundaryfixtures,100fFoutputs. RestoreONnearzeroerror/captureerrors cannotacceptcorruptedworkingstate. AfirstAGE/AMPreleasechange:V1-295/-367mV,V2-26/-45mV,V4-39/-60mV. M4guards reducecontrolC133.86/137.56to12.624/17.992fF;localstateM4route shortening leavesresidualCunchanged andreducesVSSloading. V3AGE/VDDportaliasrejectedbeforetransient,V4actualbbox/escapechannelclearancefixpassesexactgraph. NexttargetactualparallelM5horizontalendpointescapes withgroundM5guards,keepV4localstate/M4guards. No moreblindspacing/bias/runtimecampaign. IO notfullpopulationbound;15AGE/AMPforestpairs,classcurrent/globalfunctions remainopen. V10all30976000membraneconnections unchanged. Report:artifacts/analog_asic/assembly/adaptation_shared_state_io_review_v1/article_report_v1.html.








## Repaired adaptation IO and fullpopulation access V12 - 2026-10-12





V6same172MOS84MIM withgroundM5horizontalguards(source/GDSDRC0/exact256graph,2196completeverifiedC). V5guard0.40umwidthrejected,corrected0.44umV6;nativeNetgen mismatchretained.110usnativeIO+residentA-B-A completes19.969s;postreleaseAGEabout-4.24mV,AMPabout-5.12mV(Afirst),allcase4-6mV retained. Capture91.42uVmax,heldslotchangebelow0.1uV. Frozen100ohmRECOV/100fFDATAfixtures;noIC/UIC. Carryimperfectresultforward,notfloataccuracy/expiry/8slotserviceacceptance. V11actual15wrapperlayout generated;V12addslocalM4risergroundguards toavoidrecreatingcoupling. NewlinearGDSnamespaceimport preservesnativecellswithoutquadraticconcatenation;assembly4.41s. V12routes21964800AGE/AMPstates:forestRECOVâ†’IOrestoreâ†’existingresidentAGE/AMPLITUDE,AGEbuffer/existingAMP_BUFâ†’16holdbuffersâ†’8DATAeachplane. All15actualboundarymetal/contactproofs pass;aliases independentlyderivedfromunchangedV10actorpins,allnativechildrenbyteverified. Independenttopcensus/portcontract/disjointbboxreadback:56forestroots/25actors/54130nativepages,all54630400activeidentitycontracts retained;30976000membranepaths inheritedunchanged. ParentRC/calibratedAGEadvance/expiry/allchannelproducerbindings unqualified. Classcurrent1689600states stillneedcomputeaccess;globaloperators/parameters/sequencing andaccuracy/5ms open. Catalog103:20modules/88characterizationassemblies. Report:artifacts/analog_asic/assembly/full25_adaptation_service_v12/article_report_v1.html.








## Class-score shared access V13 - 2026-10-12





All54,630,400analogstate identities now have physical shared access paths:30,976,000membrane,21,964,800AGE/AMP and1,689,600class-current. V13classforest joins existing six-class readout through native120MOS8R48MIMIO; source/GDSDRC0/exact176primitiveproofs,2787completeC. Readout complete2620Cexport preserves488nativeprimitives.180usnativeA-B-Arestore/mux/downshift/capture completes18.625s,restore7.97mV/roundtrip22.32mV errors retained;firstheldslotchange0.033uV,unselectedclasschange3.37mV. Explicit100ohmRECOV/100fFDATAfixtures;EVAL/SAMPLEinactive,prior three50mswinnercases retained. Firstdecknamecollision failedparsing andpreserved;V2fixchanges names/duplicateendpoint only. Parentexact62568baseline+3947newrectangles/145anchors proofpasses without shorts/opens/floating/unknowncontacts. Independentbinarycensus preserves56forestroots/25actors/54130nativepages;existingreadout appears exactlyonce,allV12topchildren unchanged;geometry/TEXT/AREFbounds disjoint. GDS55.23MB. NativeNetgen mismatch retained separatelyfromindependentexactproof. Allnumericaccess built doesnotcomplete globalgraph/operators,trainedparameters,phase/addresssequencing,parentRC/loadedservice/accuracy/5ms. Catalog104:20modules/89characterizationassemblies. Report:artifacts/analog_asic/assembly/full25_class_current_service_v13/article_report_v1.html.





## GF180 32-lane analog actor spike serializer - 2026-10-12





Four contiguous 32-neuron banks preserve canonical channel-major ordering and are designed to feed the existing three-node sorted residual merge tree. One bank passes Icarus simulation and has routed GDS/LEF/Liberty. Its 20 ns nominal constraint gives post-route STA Fmax 109.65 MHz; a 32-lane scan takes at most 0.64 us at 50 MHz before downstream backpressure. Magic full-style flattened GDS DRC reports zero errors. OpenROAD's final detailed-route report retains two adjacent-net Metal2 spacing entries at one location; preserve this discrepancy and do not call the macro foundry signoff. The flattened four-bank parent is now routed with zero DRT violations and zero Magic DRC errors, but its final report has 120 max-slew violations. Analog actor comparator binding, full-model accuracy and 5 ms acceptance remain open. Evidence: `artifacts/analog_asic/results/gf180_analog_spike_event_serializer32_v1.json`.


## GF180 four-bank 128-neuron spike page - 2026-10-12





The integrated categorical page wrapper passes sparse sorted output, all-bank completion/tag propagation, partial final-page masking and invalid lane-count fail-closed simulation. The flattened wrapper containing four 32-lane scanners and three sorted merge nodes has routed GDS, SPEF, LEF and Liberty. Detailed-route violations are 0; flattened Magic full-style GDS DRC is 0; the 249-terminal abstract imports. Die is 1107.91 x 1107.91 um (1.227 mm2), standard-cell area 391,094 um2, Fmax 119.74 MHz at a 20 ns constraint, worst slack 11.65 ns, and default-activity digital power estimate 0.356 W. The ORFS final report has 120 max-slew violations; setup/hold violations are zero. This is the first physically routed 128-neuron event-output parent, not a full actor: actual analog comparator binding, full graph, loaded analog service and 5 ms acceptance remain open. Evidence: `artifacts/analog_asic/results/gf180_analog_spike_event_page128_v1.json`.




## Routed event graph and scalar actor boundary - 2026-10-13

The full 25-actor/53-edge categorical graph now has actual routed GDS/ODB/DEF/SPEF/LEF and an extracted 3,087-terminal physical contract. Macro size 1,730.68 x 1,730.68 um (2.995 mm2); final detailed-route violations 0. The original default 5.5V timing report retains 1,833 max-slew violations. Reanalysis of unchanged ODB/SPEF with the existing GF180 typical 25C/3.3V standard-cell library gives setup slack +2.43 ns and hold slack +0.77 ns at 20 ns. This is nominal macro STA, not full-chip or PVT closure.

The existing shared analog lane produces sequential scalar decisions, so its output cannot be treated as 128 simultaneous comparators. A new scalar result packet adapter accepts a settled sampled comparator decision plus canonical channel/y/x address and tag, suppresses non-spikes, and emits full-bin completion after the last spike handshake. Sample-valid and last-result are service-controller inputs; last-result must cover the entire actor population. RTL cases pass for sparse/silent/single-neuron bins, backpressure, final-spike ordering, tag wrap and fail-closed tag/order faults. Its routed macro is 251.315 x 251.315 um (0.06316 mm2), 119 terminals, detailed-route violations 0 and default final max-slew count 0. Nominal 3.3V setup/hold slacks +9.49/+0.82 ns at 20 ns.

Evidence: assembly/full25_event_graph_layout_v1/physical_macro.json; assembly/scalar_result_packet_layout_v1/physical_macro.json; results/scalar_result_packet_v1/simulation.json. Their timing_3v3_v1 and timing_3v3_v2 subfolders respectively retain nominal STA. Scalar timing attempt1 failed only because openroad was not on PATH; the failed log is preserved and attempt2 uses the installed executable. Neither macro has a new Magic independent DRC result. Neither is yet physically bound into V13. Full-chip functional layout, parameter/control producers, loaded analog interfaces, model accuracy and 5ms service remain incomplete. No calibration/behavior refinement was performed.


## Existing binding reconciliation and connected packet fabric - 2026-10-13

Earlier binding work is present and retained: gf180_one_neuron_page_link_v1 and gf180_neuron_page_scatter_link_v1 both have actual GDS, zero full-style Magic DRC and extracted SPIKE-to-page lane0 connectivity. Rechecked 10 and9 source/artifact hashes and the actual hierarchical SPICE link; both pass. V13 numeric-state read/restore/writeback bindings remain the physical base. These are completed partial bindings, not absent work. The earlier statement that binding was still needed refers to remaining full25 graph/parameter/control connections, not rebuilding the existing one-neuron demonstration or storage access. Evidence: assembly/full25_packet_fabric_v1/prior_binding_reconciliation_v1.json.

The next parent physically joins one existing graph macro with25 scalar-result macros, reusing their GDS/LEF and regenerated 3.3V timing abstracts. Synthesized structure independently confirms all25 adapter packet buses/handshakes/tags (1475 bit connections) and result/control slices. All numeric state/weights remain analog. The parent exposes sampled comparator results and graph actor-input ports; native actor conductors and parameter/phase/address producers still need binding.

The first hierarchical parent stopped with GPL-0305 numerical divergence in global placement, before routing. Original logs, status and failed ODB remain preserved. A bounded repair variant packet_fabric_repair1 lowers movable-cell density0.30 to0.08 and disables timing/routability-driven placement inflation; the26 macros, placements and RTL connections are unchanged. Live handle ess-gf180-full25-packet-fabric-repair1. This is a new all25 packet-fabric composition, not a rerun of the successful earlier one-neuron binding. Full-chip completion remains false.


## All25 actual spike outputs and packet-parent supply repair - 2026-10-13

New full-state GDS: assembly/full25_spike_breakouts_v15/eventspikeseg140k_spike_breakouts_v15.gds, top ESS140K_SPIKE_BREAKOUTS_V15,55,230,028bytes. Each actual compute__C_SPIKE (or existing OWN_SPIKE for stem) now has an M5 escape to a SPIKE_RESULT pad20um outside its enclosing top-level membrane/adaptation wrapper. Conservative contact proof rejects any touched M5 component other than the existing source component. Independent full-parent readback passes all25, including the enclosing-parent metal. It verifies326unchanged sourcecells bytewise and66cloned actor/ancestorcells, preserving all existing state geometry and array multiplicities. V14 internal-pad intermediate preserved. These are real analog output conductors, still not joined to the graph. New escapes have no spacingDRC/RC/loading acceptance yet.

Connected packet fabric repair1 passed detailed signal routing (finalDRT0; one antenna net/pin remains) but final_report failed PSM-0069 on VDD. At least result_14,result_19,result_24 and graph_macro VDD pins are disconnected; VSS has not yet passed independently. Source GF180 default PDN script contains only a standard-cell grid and no macro supply connection grid. Final routed5_route.odb,DEF/SPEF and logs preserved; no finalGDS/LEF acceptance. No job remains live. Next is PG connection repair using the existing routed database, then final extraction/GDS export and external SPIKE-to-fabric routes; parameter/phase/address bindings still required.

Two bounded direct add_sroute_connect attempts preserved as supply_repair_v1/repair.tcl and repair2.tcl. First rejected float pitch arguments; the installed API expects integer database units. Second aborted inside OpenROAD SRoute::addSrouteInst when invoked with the existing same-domain grid (no power ring); it produced no repairedODB. Do not repeat this command blindly or rerun the13minute signal route. Repair the lateral Metal5 macro supply-pin connection to adjacent same-net Metal4 grid with explicit geometry/contact checks, or add a suitable macroPG strategy. V15 existing SPIKE escape checks remain independent of this supply issue.


## Connected25-output graph assembly V16 - 2026-10-13

Packet fabric supply repair now completes:163M5rail joins/one-cut via connections, no existing signal-wire edits (92,853shape fingerprint/readback), bothVDD/VSS power-grid checks pass. Corrected newVia4cut0.28to0.26um withgenerated-via metadata;163newcut checks against87,248existingPGVia4cuts find0conflicts. Nominal4.5ohm via resistance comes from the local open_pdks gf180mcuD.tech contact4500milliohm entries. The installed load_design hardcodes platform/setRC.tcl and bypassesRC_FILE; supported PRE_FINAL_REPORT_TCL now applies the native nominal cut-layer resistance after loading. Prior zero-resistance/Makefile-precedence/engine-interruption failures retained. Finalreport and power calculation complete at3.3V/25C. StreamedGDS296,398,522bytes;LEF3,012terminals;26macros;4,500x3,500um(15.75mm2,packetfabric only). Finalsetup slack-0.270113ns at20ns,hold+3.49325ns,Fmax49.3337MHz,max-slew count0. Carry this small50MHzsetup miss; no timing signoff claim. Prior signalDRT0 and oneantenna net/pin retained; no full-style DRC afterPGpatch.

V16 streams the unchanged V15full-state analog library and the unchanged completed packet-fabric library into one actualGDS, then routes25actualSPIKE_RESULTconductors to matching result_spike_i inputs. Outside-macro ManhattanM4/M5tracks andM3/M4pin approaches add829rectangles. Independent binaryGDSreadback verifies both childlibraries byte-identical, rootreferences/placements,25distinct source/destination components,0opens/aliases/floatingnewmetal and0incrementalM3/M4/M5inter-net spacing conflicts. Source54,630,400state identities and native geometry inherited unchanged; full chip native inventory not recounted anew. GDS351,683,212bytes,topESS140K_SPIKE_GRAPH_V16. This retains the spacious atlas, not a compact die. LongglobalwireRC/loading and full-styleDRC remain unqualified.

Required remaining bindings: shared supplies/clock/reset, settled sample-valid, per-neuron canonical address/bin-tag and entire-population last-result, graph actor-input to analog synapse/weight service, trained analog parameter delivery and phase/address producers. These are still essential functions. No QAT/digital-state fallback or calibration campaign was introduced. FullfunctionalASIC, original-float accuracy and5ms population service are incomplete. Evidence: assembly/full25_spike_graph_v16/delivery_stage_v1.json and gds_incremental_connectivity_v1.json; assembly/full25_packet_fabric_v1/physical_macro.json and final_boundary_contract_v1.json. No live job remains.


## Decision/address producer V2 and confirmed service bound - 2026-10-13

New categorical decision scan requests one native neuron service, requires a freshlow/high settled-done, holds its canonical channel/y/x address and result-valid through packet backpressure, and waits until the scalar adapter drains the entire-population completion. It generates membrane/local64/two-bank/local1024/forest selection and auxiliaryforest addresses; numerical state and weights remain analog. Start requires completed accumulation and required populationRMS/threshold phases; native service-ready/done/hold and physicalbindings remain open.

Physical mapping audit found11low-resolution actors have excludedlocalbanks0..8,10..19:bank9is the firstforestbank,bank19is localpage. The initial contiguousbankV1smoke is preserved and is not used for layout. V2uses an explicit380-bit categorical address table from frozen physicalexceptions, including local-page slot order. Its bounded adapter-linked simulation covers5440valid neuronresults with partialedge tiles, allfourserviceclasses, noncontiguous bankrank, auxiliaryaddress, canonical ordering, freshacknowledgment, backpressure, finalspike/completion, silentbin andreset. Independentgeneratedparameter audit checks all490240membranebanks, rank/inverse and exactvalidedge counts for30976000membranes across25originalfloat actors.

A concrete5ms architectural gap is confirmed: current one-serial-service-peractor cannot meet real-time5ms even if analog work were instantaneous. REQUEST,WAIT_SERVICE,PUBLISH require at least3clockcycles perneuron. At the controller25ns(40MHz)constraint the largest4,505,600-neuron actor needs at least0.33792s; at least68independent service lanes would be needed for thatactor before actualanalog service, storage contention, outputtraffic orgraph latency. This is a minimum, not the selected lane count. Addresslogic remains reusable; fullpopulationserial service must not be accepted for5ms. Next architecture work must partition state-access trees and replicate analogservice/results according to loaded native timing and traffic, while continuing requiredlayout/control/parameter bindings. No fullmodelSPICE or QAT fallback.

The25actual-shape controller top is running a bounded30minute nominal3.3VGF180physical flow: ess-gf180-full25-decision-control-v2. It reuses the proven PRE_FINAL_REPORT nominalvia-resistance hook. V16connected-output layout stays the current assembledGDS. Evidence: results/decision_scan_v2/simulation.json; assembly/full25_decision_control_v2/status.json, all_actor_address_map_v1.json, serial_service_lower_bound_v1.json. Controller layout/physicalbinding, fullfunctionalASIC, accuracy and5ms remain incomplete.
