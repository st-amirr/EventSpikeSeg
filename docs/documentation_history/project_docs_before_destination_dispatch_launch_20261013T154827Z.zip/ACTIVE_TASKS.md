# Active tasks

Updated 2026-10-13. This page is the current operational scope. Earlier task requirements are archived.

## Active scope clarification — 2026-10-13

The user defines this deliverable as an article-suitable analog/mixed-signal implementation of the EventSpikeSeg140k architecture: full physical layout with membrane storage and event-to-membrane accumulation, followed by per-module simulations. The original epoch58 float model defines topology and state identities; QAT is unnecessary.

The 5 ms real-time requirement applies to delivery and accumulation of supplied input events onto their destination membranes. It does not require threshold/output generation, a full layer-to-layer inference pass, or final segmentation within 5 ms. For module timing, state exactly which input event workload and destinations were exercised; do not infer a full-model deadline pass from a small example. Later-layer workloads may be supplied externally for module characterization; this is not autonomous end-to-end inference.

Trained-weight loading, transfer, programming and exact checkpoint weight reproduction are outside the required completion gates. Retain the synaptic contribution/weight-control interfaces and existing physical synapse circuitry: an externally applied analog magnitude/sign is an explicit research interface, not a claim of loaded trained weights. Events must still have physical paths to selected membrane capacitors; removing weight transfer does not remove event fanout, charge injection or membrane access time.

A useful segmentation output, hardware mIoU, PyTorch-equivalent accuracy, calibration optimization and manufacture-ready signoff are not required. Preserve existing threshold/reset/adaptation/readout modules as architecture components and report their connectivity and simulation coverage, without requiring output completion for the accumulation deadline.

Completion requires a real hierarchical full-architecture GDS, inventory and connection/boundary manifest, and per-module simulation results including selected-event membrane accumulation/retention and measured timing. Explicit external interfaces are allowed. Opens/shorts in paths claimed connected remain vital defects. Never call an unconnected placement a functioning full ASIC or claim 5 ms compliance without corresponding evidence.

Next work: integrate the existing packet fabric and ingress/address macros with the membrane-access/injection architecture, expose analog contribution and phase controls, export the full architecture layout, then finish per-module simulations. Do not start trained-weight programming or output-accuracy campaigns. The old 68-decision-service lower bound is not an active completion gate. Existing packet/group lower bounds remain conditional on their supplied workload and assumed delivery architecture; they are not automatically waived or proven satisfied.

This scope supersedes conflicting older requirements below. Existing results and failures remain unchanged. No physical Docker jobs are live.

## Physical accumulation architecture integration — 2026-10-13

New full-population V17 GDS: `artifacts/analog_asic/assembly/full25_accumulation_architecture_v17/eventspikeseg140k_accumulation_architecture_v17.gds` (427,483,212 bytes), top `ESS140K_ACCUMULATION_ARCHITECTURE_V17`. It preserves all source analog state geometry, integrates the actual routed fabric/ingress pair, and retains all 25 native SPIKE outputs connected to that fabric. The 1,475 previously RTL-only fabric-to-ingress event/ready/payload/completion/tag connections are now physical metal; two shared clock/reset routes connect those two macros. Existing global clock/reset/power distribution remains incomplete.

Actual pair GDS readback passes all 1,477 new paths with no opens, aliases or floating additions. Its native contact check covers the 2 um macro perimeter band and verifies that new parent metal does not intrude beyond that band; original child cells are preserved (ingress names systematically prefixed). This is an incremental connection check, not full device extraction or full-style DRC. Evidence: `assembly/accumulation_fabric_ingress_v1/independent_readback_v1.json`.

Actual V17 GDS readback proves both source libraries byte-identical, all 25 rerouted spike paths connected, zero opens/aliases/floating metal or cuts, zero screened route spacing/cross-contact conflicts, and no unrelated macro intrusion. Outer spike channels now use M1/M2 while retaining their native M5 source and M3/M4 destination approaches, separating them from new ingress M3/M4/M5 routing. Evidence: `assembly/full25_accumulation_architecture_v17/independent_readback_v1.json`.

Current stage: destination-to-membrane integration. Ingress produces x/y/channel-group destinations, but conversion/dispatch to native local/forest page addressing and required read/restore/inject/capture/commit controls still need binding. Analog magnitude/sign and phases can be external research interfaces under the clarified scope. Global supplies/references and clock/reset distribution remain required. The full architecture layout is not yet complete and 5 ms accumulation is not verified. Trained-weight loading, useful inference output and hardware mIoU remain excluded completion gates. Parent RC/loading and per-module connected-event timing remain to be measured. This remains a spacious research atlas, with no compact die area claim. No Docker jobs were launched for these GDS assembly/readback steps.

## Current evidence

- Full-population V16: `artifacts/analog_asic/assembly/full25_spike_graph_v16/physical_assembly.json`.
- Connected native page access/injector pair: `artifacts/analog_asic/assembly/controlled_page_service_pair_v3/independent_readback_v3.json`.
- Native independent page roots: `artifacts/analog_asic/assembly/parallel_storage_roots_v4/independent_readback_v1.json`.
- Existing module simulation coverage: `artifacts/analog_asic/assembly/full25_class_current_service_v13/module_simulation_coverage_v1.json`; coverage is historical evidence, not a new full-chip pass.
- Docker cleanup: `artifacts/analog_asic/operations/storage_cleanup_20261013/cleanup_summary.json`; terminal containers removed, canonical views retained. Use --rm for bounded simulations and archive/remove detached jobs on completion.

## Working rules

Layout first, then per-module simulation. Only vital connectivity/function changes. Use existing modules, existing Docker images and existing docs; no new Markdown files, no QAT/digital membrane fallback, no full-model SPICE, no subagents without authorization. Preserve unique artifacts and failed evidence. Archive the seven project docs before changing them.

Previous operational text: `docs/documentation_history/project_docs_before_accumulation_scope_20261013T143018Z.zip`.
